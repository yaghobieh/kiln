#!/usr/bin/env node
/**
 * Kiln CLI - Component documentation and showcase tool
 * 
 * Usage:
 *   kiln dev           - Start dev server with HMR
 *   kiln build         - Build static documentation
 *   kiln preview       - Preview built documentation
 */

import { spawn } from 'child_process';
import { existsSync, readFileSync, writeFileSync, mkdirSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
void __filename; // Keep for potential future use

// Colors for terminal output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  cyan: '\x1b[36m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  red: '\x1b[31m',
  magenta: '\x1b[35m',
};

const log = {
  info: (msg: string) => console.log(`${colors.cyan}ℹ${colors.reset} ${msg}`),
  success: (msg: string) => console.log(`${colors.green}✓${colors.reset} ${msg}`),
  warn: (msg: string) => console.log(`${colors.yellow}⚠${colors.reset} ${msg}`),
  error: (msg: string) => console.log(`${colors.red}✗${colors.reset} ${msg}`),
  title: (msg: string) => console.log(`\n${colors.magenta}${colors.bright}🔥 ${msg}${colors.reset}\n`),
};

interface KilnConfig {
  title?: string;
  description?: string;
  logo?: string;
  theme?: 'light' | 'dark' | 'auto';
  primaryColor?: string;
  stories?: string[];
  port?: number;
  showCodeDefault?: boolean;
  testing?: boolean;
  /** CSS file to import (e.g., "@forgedevstack/bear/styles.css") */
  cssImport?: string;
  /** Provider wrapper import (e.g., { from: "@forgedevstack/bear", name: "BearProvider" }) */
  wrapper?: {
    from: string;
    name: string;
    props?: Record<string, unknown>;
  };
}

const DEFAULT_CONFIG: KilnConfig = {
  title: 'Kiln',
  description: 'Component Documentation',
  theme: 'dark',
  primaryColor: '#ec4899',
  stories: ['src/**/*.kiln.tsx', 'src/**/*.story.tsx', 'src/**/*.stories.tsx'],
  port: 6006,
  showCodeDefault: true,
  testing: false,
};

const CONFIG_FILE_NAME = 'kiln.config.json';

function findConfigFile(startDir: string): string | null {
  let currentDir = startDir;
  while (currentDir !== '/') {
    const configPath = join(currentDir, CONFIG_FILE_NAME);
    if (existsSync(configPath)) {
      return configPath;
    }
    currentDir = dirname(currentDir);
  }
  return null;
}

function loadConfig(cwd: string): KilnConfig {
  const configPath = findConfigFile(cwd);
  if (configPath) {
    try {
      const content = readFileSync(configPath, 'utf-8');
      return { ...DEFAULT_CONFIG, ...JSON.parse(content) };
    } catch {
      log.warn(`Could not parse ${CONFIG_FILE_NAME}, using defaults`);
    }
  }
  return DEFAULT_CONFIG;
}

function createDefaultConfig(cwd: string): void {
  const configPath = join(cwd, CONFIG_FILE_NAME);
  writeFileSync(configPath, JSON.stringify(DEFAULT_CONFIG, null, 2));
  log.success(`Created ${CONFIG_FILE_NAME}`);
}

// Reserved for future static build functionality
// function generateStoriesIndex(cwd: string, config: KilnConfig): string { ... }

async function startDevServer(cwd: string, config: KilnConfig): Promise<void> {
  log.title('Kiln Development Server');
  log.info(`Starting on port ${config.port}...`);
  
  // Create .kiln temp directory
  const kilnDir = join(cwd, '.kiln');
  if (!existsSync(kilnDir)) {
    mkdirSync(kilnDir, { recursive: true });
  }
  
  // Build imports based on config
  const cssImportLine = config.cssImport ? `import '${config.cssImport}';` : '';
  const wrapperImportLine = config.wrapper 
    ? `import { ${config.wrapper.name} } from '${config.wrapper.from}';`
    : '';
  const wrapperProps = config.wrapper?.props 
    ? Object.entries(config.wrapper.props)
        .map(([key, value]) => `${key}={${JSON.stringify(value)}}`)
        .join(' ')
    : '';
  const wrapperStart = config.wrapper ? `<${config.wrapper.name} ${wrapperProps}>` : '';
  const wrapperEnd = config.wrapper ? `</${config.wrapper.name}>` : '';

  // Generate entry file that imports all stories
  const entryContent = `
import React from 'react';
import ReactDOM from 'react-dom/client';
import { KilnProvider, KilnLayout } from '@forgedevstack/kiln';
${cssImportLine}
${wrapperImportLine}

// Import stories dynamically
const storyModules = import.meta.glob(['../src/**/*.kiln.tsx', '../src/**/*.story.tsx', '../src/**/*.stories.tsx'], { eager: true });

// Parse story modules
const storyGroups = Object.entries(storyModules).map(([path, mod]: [string, any]) => {
  const defaultExport = mod.default;
  if (defaultExport?.title) {
    return {
      ...defaultExport,
      path,
    };
  }
  return null;
}).filter(Boolean);

const config = ${JSON.stringify(config)};

function App() {
  return (
    ${wrapperStart}
    <KilnProvider config={config} storyGroups={storyGroups}>
      <KilnLayout />
    </KilnProvider>
    ${wrapperEnd}
  );
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
`;

  writeFileSync(join(kilnDir, 'main.tsx'), entryContent);
  
  // Generate index.html
  const htmlContent = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${config.title || 'Kiln'}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: system-ui, -apple-system, sans-serif; }
  </style>
</head>
<body>
  <div id="root"></div>
  <script type="module" src="./main.tsx"></script>
</body>
</html>
`;

  writeFileSync(join(kilnDir, 'index.html'), htmlContent);
  
  // Generate tailwind config for .kiln - inherits from parent project's tailwind config
  const tailwindConfig = `
/** @type {import('tailwindcss').Config} */
import parentConfig from '../tailwind.config.js';

export default {
  ...parentConfig,
  content: [
    '../src/**/*.{js,ts,jsx,tsx}',
    './main.tsx',
  ],
};
`;

  writeFileSync(join(kilnDir, 'tailwind.config.js'), tailwindConfig);
  
  // Generate postcss config
  const postcssConfig = `
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
`;

  writeFileSync(join(kilnDir, 'postcss.config.js'), postcssConfig);

  // Generate vite config for .kiln
  const viteConfig = `
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve } from 'path';

export default defineConfig({
  plugins: [react()],
  root: '${kilnDir}',
  server: {
    port: ${config.port},
    open: true,
  },
  resolve: {
    alias: {
      '@': resolve('${cwd}', 'src'),
    },
  },
  css: {
    postcss: '${kilnDir}',
  },
});
`;

  writeFileSync(join(kilnDir, 'vite.config.ts'), viteConfig);
  
  // Run vite dev server
  const viteProcess = spawn('npx', ['vite', '--config', join(kilnDir, 'vite.config.ts')], {
    cwd: kilnDir,
    stdio: 'inherit',
    shell: true,
  });
  
  viteProcess.on('error', (err) => {
    log.error(`Failed to start dev server: ${err.message}`);
    process.exit(1);
  });
  
  process.on('SIGINT', () => {
    viteProcess.kill();
    process.exit(0);
  });
}

// Main CLI
async function main(): Promise<void> {
  const args = process.argv.slice(2);
  const command = args[0];
  const cwd = process.cwd();
  
  switch (command) {
    case 'init': {
      createDefaultConfig(cwd);
      log.info('Run `npx kiln dev` to start the development server');
      break;
    }
    
    case 'dev': {
      const config = loadConfig(cwd);
      await startDevServer(cwd, config);
      break;
    }
    
    case 'build': {
      log.title('Building Kiln Documentation');
      log.info('Static build not implemented yet');
      break;
    }
    
    case 'preview': {
      log.title('Previewing Kiln Documentation');
      log.info('Preview not implemented yet');
      break;
    }
    
    default: {
      console.log(`
${colors.magenta}${colors.bright}🔥 Kiln${colors.reset} - Component Documentation Tool

${colors.bright}Usage:${colors.reset}
  kiln init      Create kiln.config.json
  kiln dev       Start development server
  kiln build     Build static documentation
  kiln preview   Preview built documentation

${colors.bright}Options:${colors.reset}
  --port <num>   Override port (default: 6006)
  --help         Show this help
`);
    }
  }
}

main().catch((err) => {
  log.error(err.message);
  process.exit(1);
});

