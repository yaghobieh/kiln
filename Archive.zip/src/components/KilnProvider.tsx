import { createContext, useContext, useState, useMemo, ReactNode, FC } from 'react';
import type { KilnConfig, StoryGroup } from '../types';
import { DEFAULT_CONFIG } from '../types';

interface KilnContextValue {
  config: KilnConfig;
  stories: StoryGroup[];
  activeStory: { groupIndex: number; storyIndex: number } | null;
  setActiveStory: (groupIndex: number, storyIndex: number) => void;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  showCode: boolean;
  toggleShowCode: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

const KilnContext = createContext<KilnContextValue | null>(null);

interface KilnProviderProps {
  children: ReactNode;
  config?: Partial<KilnConfig>;
  stories?: StoryGroup[];
  storyGroups?: StoryGroup[];
}

/**
 * KilnProvider - Wraps your Kiln documentation app
 */
export const KilnProvider: FC<KilnProviderProps> = ({
  children,
  config: userConfig,
  stories: propStories,
  storyGroups: propStoryGroups,
}) => {
  const config = { ...DEFAULT_CONFIG, ...userConfig };
  const stories = propStories || propStoryGroups || [];

  const [activeStory, setActiveStoryState] = useState<{ groupIndex: number; storyIndex: number } | null>(
    stories.length > 0 ? { groupIndex: 0, storyIndex: 0 } : null
  );
  const [theme, setTheme] = useState<'light' | 'dark'>(
    config.theme === 'auto' ? 'dark' : (config.theme || 'dark')
  );
  const [showCode, setShowCode] = useState(config.showCodeDefault ?? true);
  const [searchQuery, setSearchQuery] = useState('');

  const setActiveStory = (groupIndex: number, storyIndex: number) => {
    setActiveStoryState({ groupIndex, storyIndex });
  };

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const toggleShowCode = () => {
    setShowCode((prev) => !prev);
  };

  const value = useMemo(
    () => ({
      config,
      stories,
      activeStory,
      setActiveStory,
      theme,
      toggleTheme,
      showCode,
      toggleShowCode,
      searchQuery,
      setSearchQuery,
    }),
    [config, stories, activeStory, theme, showCode, searchQuery]
  );

  return (
    <KilnContext.Provider value={value}>
      <div className={theme === 'dark' ? 'kiln-dark' : 'kiln-light'}>
        {children}
      </div>
    </KilnContext.Provider>
  );
};

/**
 * Hook to access Kiln context
 */
export const useKiln = (): KilnContextValue => {
  const context = useContext(KilnContext);
  if (!context) {
    throw new Error('useKiln must be used within a KilnProvider');
  }
  return context;
};
