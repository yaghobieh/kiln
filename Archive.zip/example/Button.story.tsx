/**
 * Example story file for Kiln
 * 
 * Usage:
 *   1. Create .story.tsx or .stories.tsx files
 *   2. Import and use defineStory, defineStories
 *   3. Run kiln dev to preview
 */

import { defineStory, defineStories } from '../src';

// Example Button component
const Button = ({ 
  variant = 'primary', 
  size = 'md', 
  children 
}: { 
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  children: React.ReactNode;
}) => {
  const baseStyles = {
    padding: size === 'sm' ? '6px 12px' : size === 'lg' ? '12px 24px' : '8px 16px',
    fontSize: size === 'sm' ? '12px' : size === 'lg' ? '16px' : '14px',
    borderRadius: '8px',
    border: 'none',
    cursor: 'pointer',
    fontWeight: 500,
    transition: 'all 0.2s',
  };

  const variantStyles = {
    primary: {
      backgroundColor: '#d97706',
      color: '#ffffff',
    },
    secondary: {
      backgroundColor: '#a855f7',
      color: '#ffffff',
    },
    outline: {
      backgroundColor: 'transparent',
      color: '#d97706',
      border: '2px solid #d97706',
    },
    ghost: {
      backgroundColor: 'transparent',
      color: '#d97706',
    },
  };

  return (
    <button style={{ ...baseStyles, ...variantStyles[variant] }}>
      {children}
    </button>
  );
};

// Define stories for Button
export default defineStories({
  title: 'Button',
  component: Button,
  description: 'A versatile button component with multiple variants and sizes.',
  stories: [
    defineStory({
      name: 'Primary',
      render: Button,
      args: { variant: 'primary', children: 'Primary Button' },
      code: `<Button variant="primary">Primary Button</Button>`,
      description: 'The default primary button style with amber/orange color.',
    }),
    defineStory({
      name: 'Secondary',
      render: Button,
      args: { variant: 'secondary', children: 'Secondary Button' },
      code: `<Button variant="secondary">Secondary Button</Button>`,
      description: 'Purple secondary button for less prominent actions.',
    }),
    defineStory({
      name: 'Outline',
      render: Button,
      args: { variant: 'outline', children: 'Outline Button' },
      code: `<Button variant="outline">Outline Button</Button>`,
      description: 'Transparent button with a border.',
    }),
    defineStory({
      name: 'Ghost',
      render: Button,
      args: { variant: 'ghost', children: 'Ghost Button' },
      code: `<Button variant="ghost">Ghost Button</Button>`,
      description: 'Minimal button with no background or border.',
    }),
    defineStory({
      name: 'Small',
      render: Button,
      args: { variant: 'primary', size: 'sm', children: 'Small' },
      code: `<Button size="sm">Small</Button>`,
      description: 'Compact size for tight spaces.',
    }),
    defineStory({
      name: 'Large',
      render: Button,
      args: { variant: 'primary', size: 'lg', children: 'Large Button' },
      code: `<Button size="lg">Large Button</Button>`,
      description: 'Larger size for prominent CTAs.',
    }),
  ],
});
