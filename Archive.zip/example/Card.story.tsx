/**
 * Card Story for Kiln
 * Shows a container component with variants
 */

import { defineStory, defineStories } from '../src';

// Example Card component
const Card = ({
  variant = 'default',
  title,
  children,
}: {
  variant?: 'default' | 'elevated' | 'outlined' | 'glass';
  title?: string;
  children: React.ReactNode;
}) => {
  const baseStyles: React.CSSProperties = {
    padding: '24px',
    borderRadius: '12px',
    maxWidth: '320px',
  };

  const variantStyles: Record<string, React.CSSProperties> = {
    default: {
      backgroundColor: '#1f1f23',
      border: '1px solid #27272a',
    },
    elevated: {
      backgroundColor: '#1f1f23',
      boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
    },
    outlined: {
      backgroundColor: 'transparent',
      border: '2px solid #d97706',
    },
    glass: {
      backgroundColor: 'rgba(255,255,255,0.1)',
      backdropFilter: 'blur(10px)',
      border: '1px solid rgba(255,255,255,0.2)',
    },
  };

  return (
    <div style={{ ...baseStyles, ...variantStyles[variant] }}>
      {title && (
        <h3 style={{ margin: '0 0 12px', fontSize: '18px', fontWeight: 600, color: '#fafafa' }}>
          {title}
        </h3>
      )}
      <div style={{ color: '#a1a1aa', lineHeight: 1.6 }}>{children}</div>
    </div>
  );
};

export default defineStories({
  title: 'Card',
  component: Card,
  description: 'A flexible container component for grouping related content.',
  stories: [
    defineStory({
      name: 'Default',
      render: Card,
      args: { 
        title: 'Default Card',
        children: 'This is a basic card with default styling. Great for general content containers.' 
      },
      code: `<Card title="Default Card">
  This is a basic card with default styling.
</Card>`,
      description: 'The default card with subtle border.',
    }),
    defineStory({
      name: 'Elevated',
      render: Card,
      args: { 
        variant: 'elevated',
        title: 'Elevated Card',
        children: 'This card has a shadow for depth. Use for important or featured content.' 
      },
      code: `<Card variant="elevated" title="Elevated Card">
  Content with shadow depth.
</Card>`,
      description: 'Card with shadow for visual emphasis.',
    }),
    defineStory({
      name: 'Outlined',
      render: Card,
      args: { 
        variant: 'outlined',
        title: 'Outlined Card',
        children: 'Transparent background with a colored border. Great for secondary content.' 
      },
      code: `<Card variant="outlined" title="Outlined">
  Transparent with border.
</Card>`,
      description: 'Transparent card with branded border.',
    }),
    defineStory({
      name: 'Glass',
      render: Card,
      args: { 
        variant: 'glass',
        title: 'Glass Card',
        children: 'Modern glassmorphism effect with blur. Perfect for overlay content.' 
      },
      code: `<Card variant="glass" title="Glass Card">
  Glassmorphism effect.
</Card>`,
      description: 'Frosted glass effect (requires background).',
    }),
  ],
});

