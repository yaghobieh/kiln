/**
 * Example Kiln App
 * Shows how to set up Kiln with your components
 */

import { KilnProvider, KilnLayout } from '../src';
import type { StoryGroup } from '../src/types';

// Import your stories
import buttonStories from './Button.story';
import cardStories from './Card.story';
import badgeStories from './Badge.story';

// Collect all stories
const stories: StoryGroup[] = [
  buttonStories,
  cardStories,
  badgeStories,
  // Add more story groups here
];

// Kiln configuration
const config = {
  title: 'My Component Library',
  description: 'Documentation for my components',
  primaryColor: '#d97706',
  theme: 'dark' as const,
};

function App() {
  return (
    <KilnProvider config={config} stories={stories}>
      <KilnLayout />
    </KilnProvider>
  );
}

export default App;
