import { ReactNode, ComponentType } from 'react';

/**
 * Kiln Configuration File (kiln.config.json)
 */
export interface KilnConfig {
  /** Title of the documentation site */
  title?: string;
  /** Description for SEO */
  description?: string;
  /** Logo path or URL */
  logo?: string;
  /** Theme mode */
  theme?: 'light' | 'dark' | 'auto';
  /** Primary brand color */
  primaryColor?: string;
  /** Stories glob pattern */
  stories?: string[];
  /** Port for dev server */
  port?: number;
  /** Whether to show code by default */
  showCodeDefault?: boolean;
  /** Whether to enable testing panel */
  testing?: boolean;
}

export const DEFAULT_CONFIG: KilnConfig = {
  title: 'Kiln',
  description: 'Component Documentation & Showcase',
  theme: 'dark',
  primaryColor: '#d97706',
  stories: ['**/*.story.tsx', '**/*.stories.tsx'],
  port: 6006,
  showCodeDefault: true,
  testing: false,
};

/**
 * Story definition
 */
export interface Story<P = unknown> {
  /** Story name */
  name: string;
  /** Component to render */
  component: ComponentType<P>;
  /** Default props */
  args?: P;
  /** Source code to display */
  code?: string;
  /** Description of the story */
  description?: string;
}

/**
 * Story Group (a file)
 */
export interface StoryGroup {
  /** Group title (e.g., "Button") */
  title: string;
  /** Component being documented */
  component?: ComponentType;
  /** Individual stories */
  stories: Story[];
  /** Description of the component */
  description?: string;
  /** Path to the story file */
  path?: string;
}

/**
 * Props for KilnCanvas (the preview area)
 */
export interface KilnCanvasProps {
  /** Background color */
  background?: 'transparent' | 'light' | 'dark' | 'checker';
  /** Whether to center content */
  centered?: boolean;
  /** Padding around content */
  padding?: 'none' | 'sm' | 'md' | 'lg';
  /** Children to render */
  children: ReactNode;
}

/**
 * Props for KilnControls (interactive controls)
 */
export interface KilnControlDef {
  name: string;
  type: 'boolean' | 'string' | 'number' | 'select' | 'color' | 'range';
  defaultValue?: unknown;
  options?: string[] | number[];
  min?: number;
  max?: number;
  step?: number;
  description?: string;
}

/**
 * Prop types for component documentation
 */
export interface PropDef {
  name: string;
  type: string;
  required?: boolean;
  defaultValue?: string;
  description?: string;
}

export interface ComponentDoc {
  name: string;
  description?: string;
  props: PropDef[];
}

