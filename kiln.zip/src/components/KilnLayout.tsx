import { FC, useState, useMemo } from 'react';
import { useKiln } from './KilnProvider';

type Breakpoint = 'mobile' | 'tablet' | 'desktop' | 'full';

const BREAKPOINTS: Record<Breakpoint, { width: string; label: string }> = {
  mobile: { width: '375px', label: '375px' },
  tablet: { width: '768px', label: '768px' },
  desktop: { width: '1280px', label: '1280px' },
  full: { width: '100%', label: 'Full' },
};

// SVG Icons
const Icons = {
  Mobile: () => (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="5" y="2" width="14" height="20" rx="2" ry="2" />
      <line x1="12" y1="18" x2="12.01" y2="18" />
    </svg>
  ),
  Tablet: () => (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="4" y="2" width="16" height="20" rx="2" ry="2" />
      <line x1="12" y1="18" x2="12.01" y2="18" />
    </svg>
  ),
  Desktop: () => (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
      <line x1="8" y1="21" x2="16" y2="21" />
      <line x1="12" y1="17" x2="12" y2="21" />
    </svg>
  ),
  Expand: () => (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="15 3 21 3 21 9" />
      <polyline points="9 21 3 21 3 15" />
      <line x1="21" y1="3" x2="14" y2="10" />
      <line x1="3" y1="21" x2="10" y2="14" />
    </svg>
  ),
  Code: () => (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="16 18 22 12 16 6" />
      <polyline points="8 6 2 12 8 18" />
    </svg>
  ),
  ChevronRight: () => (
    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="9 18 15 12 9 6" />
    </svg>
  ),
  ChevronDown: () => (
    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="6 9 12 15 18 9" />
    </svg>
  ),
  Component: () => (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polygon points="12 2 22 8.5 22 15.5 12 22 2 15.5 2 8.5 12 2" />
      <line x1="12" y1="22" x2="12" y2="15.5" />
      <polyline points="22 8.5 12 15.5 2 8.5" />
    </svg>
  ),
  Story: () => (
    <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor">
      <circle cx="12" cy="12" r="4" />
    </svg>
  ),
  Menu: () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="3" y1="12" x2="21" y2="12" />
      <line x1="3" y1="6" x2="21" y2="6" />
      <line x1="3" y1="18" x2="21" y2="18" />
    </svg>
  ),
  Sun: () => (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="5" />
      <line x1="12" y1="1" x2="12" y2="3" />
      <line x1="12" y1="21" x2="12" y2="23" />
      <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
      <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
      <line x1="1" y1="12" x2="3" y2="12" />
      <line x1="21" y1="12" x2="23" y2="12" />
      <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
      <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
    </svg>
  ),
  Moon: () => (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
    </svg>
  ),
  Copy: () => (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
    </svg>
  ),
};

/**
 * KilnLayout - Main layout with tree sidebar, canvas, and inline docs
 */
export const KilnLayout: FC = () => {
  const { 
    config, 
    stories, 
    activeStory, 
    setActiveStory, 
    theme, 
    toggleTheme,
    showCode,
    toggleShowCode,
    searchQuery,
    setSearchQuery,
  } = useKiln();

  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set(stories.map(s => s.title)));
  const [breakpoint, setBreakpoint] = useState<Breakpoint>('full');
  const [liveArgs, setLiveArgs] = useState<Record<string, unknown>>({});

  // Toggle group expansion
  const toggleGroup = (title: string) => {
    const next = new Set(expandedGroups);
    if (next.has(title)) {
      next.delete(title);
    } else {
      next.add(title);
    }
    setExpandedGroups(next);
  };

  // Filter stories based on search
  const filteredStories = stories.filter((group) =>
    group.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    group.stories.some((s) => s.name.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  // Get current story
  const currentGroup = activeStory ? stories[activeStory.groupIndex] : null;
  const currentStory = currentGroup && activeStory
    ? currentGroup.stories[activeStory.storyIndex]
    : null;

  // Merge live args with story args
  const mergedArgs = useMemo(() => {
    return { ...(currentStory?.args || {}), ...liveArgs };
  }, [currentStory?.args, liveArgs]);

  // Reset live args when story changes
  const handleStoryChange = (groupIndex: number, storyIndex: number) => {
    setActiveStory(groupIndex, storyIndex);
    setLiveArgs({});
  };

  // Get prop info from args with better type detection
  const propEntries = useMemo(() => {
    if (!currentStory?.args) return [];
    const args = currentStory.args as Record<string, unknown>;
    return Object.entries(args).map(([key, value]) => {
      const currentValue = (mergedArgs as Record<string, unknown>)[key];
      // Detect possible options based on common patterns
      let options: string[] | undefined;
      if (typeof value === 'string') {
        if (key === 'variant' || key === 'color' || key === 'size') {
          // Common variant/size options
          if (key === 'variant') options = ['primary', 'secondary', 'outline', 'ghost', 'danger', 'success'];
          if (key === 'color') options = ['default', 'primary', 'secondary', 'success', 'warning', 'danger'];
          if (key === 'size') options = ['xs', 'sm', 'md', 'lg', 'xl'];
        }
      }
      return {
        name: key,
        type: typeof value,
        value: currentValue,
        defaultValue: value,
        options,
      };
    });
  }, [currentStory?.args, mergedArgs]);

  // Theme colors - cyan theme
  const PRIMARY = '#0891b2';
  const colors = {
    bg: theme === 'dark' ? '#09090b' : '#fafafa',
    bgSecondary: theme === 'dark' ? '#0f0f12' : '#f4f4f5',
    bgTertiary: theme === 'dark' ? '#18181b' : '#e4e4e7',
    border: theme === 'dark' ? '#27272a' : '#d4d4d8',
    text: theme === 'dark' ? '#fafafa' : '#18181b',
    textMuted: theme === 'dark' ? '#71717a' : '#a1a1aa',
    primary: PRIMARY,
  };

  return (
    <div 
      className="kiln-layout"
      style={{
        display: 'flex',
        height: '100vh',
        backgroundColor: colors.bg,
        color: colors.text,
        fontFamily: '"Inter", "SF Pro Display", -apple-system, system-ui, sans-serif',
        fontSize: '13px',
        lineHeight: 1.5,
      }}
    >
      {/* Sidebar - Tree Structure */}
      <aside
        style={{
          width: sidebarOpen ? '240px' : '0',
          borderRight: `1px solid ${colors.border}`,
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
          transition: 'width 0.15s ease',
          backgroundColor: colors.bgSecondary,
          flexShrink: 0,
        }}
      >
        {/* Header */}
        <div
          style={{
            padding: '12px 14px',
            borderBottom: `1px solid ${colors.border}`,
            display: 'flex',
            alignItems: 'center',
            gap: '10px',
          }}
        >
          <KilnLogo size={22} primaryColor={colors.primary} />
          <span style={{ fontWeight: 600, fontSize: '14px', letterSpacing: '-0.02em' }}>
            {config.title}
          </span>
        </div>

        {/* Search */}
        <div style={{ padding: '10px 12px' }}>
          <input
            type="text"
            placeholder="Search..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{
              width: '100%',
              padding: '7px 10px',
              borderRadius: '6px',
              border: `1px solid ${colors.border}`,
              backgroundColor: colors.bg,
              color: 'inherit',
              fontSize: '13px',
              outline: 'none',
            }}
          />
        </div>

        {/* Tree Navigation */}
        <nav style={{ flex: 1, overflow: 'auto', padding: '4px 8px' }}>
          {filteredStories.map((group) => {
            const isExpanded = expandedGroups.has(group.title);
            const groupIndex = stories.indexOf(group);
            
            return (
              <div key={group.title} style={{ marginBottom: '2px' }}>
                {/* Group Header (Component) */}
                <button
                  onClick={() => toggleGroup(group.title)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    width: '100%',
                    padding: '6px 8px',
                    border: 'none',
                    background: 'none',
                    cursor: 'pointer',
                    color: colors.text,
                    fontSize: '13px',
                    fontWeight: 500,
                    gap: '6px',
                    borderRadius: '4px',
                  }}
                >
                  <span style={{ 
                    transition: 'transform 0.15s',
                    transform: isExpanded ? 'rotate(0deg)' : 'rotate(-90deg)',
                    color: colors.textMuted,
                    display: 'flex',
                  }}>
                    <Icons.ChevronDown />
                  </span>
                  <span style={{ color: colors.primary, display: 'flex' }}>
                    <Icons.Component />
                  </span>
                  {group.title}
                </button>

                {/* Stories (Variants) */}
                {isExpanded && (
                  <div style={{ marginLeft: '16px', borderLeft: `1px solid ${colors.border}`, paddingLeft: '8px' }}>
                    {group.stories.map((story, storyIndex) => {
                      const isActive =
                        activeStory?.groupIndex === groupIndex &&
                        activeStory?.storyIndex === storyIndex;
                      return (
                        <button
                          key={story.name}
                          onClick={() => handleStoryChange(groupIndex, storyIndex)}
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            width: '100%',
                            padding: '5px 8px',
                            border: 'none',
                            borderRadius: '4px',
                            cursor: 'pointer',
                            backgroundColor: isActive ? `${colors.primary}15` : 'transparent',
                            color: isActive ? colors.primary : colors.textMuted,
                            fontSize: '13px',
                            gap: '6px',
                            textAlign: 'left',
                          }}
                        >
                          <span style={{ 
                            opacity: isActive ? 1 : 0.4,
                            display: 'flex',
                          }}>
                            <Icons.Story />
                          </span>
                          {story.name}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </nav>

        {/* Footer */}
        <div
          style={{
            padding: '10px 12px',
            borderTop: `1px solid ${colors.border}`,
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <button
            onClick={toggleTheme}
            style={{
              padding: '6px',
              borderRadius: '4px',
              border: 'none',
              cursor: 'pointer',
              backgroundColor: colors.bgTertiary,
              color: colors.textMuted,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            {theme === 'dark' ? <Icons.Sun /> : <Icons.Moon />}
          </button>
          <span style={{ fontSize: '11px', color: colors.textMuted }}>
            Kiln v0.1.0
          </span>
        </div>
      </aside>

      {/* Main Content */}
      <main style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', minWidth: 0 }}>
        {/* Toolbar */}
        <div
          style={{
            padding: '8px 16px',
            borderBottom: `1px solid ${colors.border}`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            backgroundColor: colors.bgSecondary,
            gap: '16px',
            flexShrink: 0,
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', minWidth: 0 }}>
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              style={{
                padding: '4px',
                borderRadius: '4px',
                border: 'none',
                cursor: 'pointer',
                backgroundColor: 'transparent',
                color: colors.textMuted,
                display: 'flex',
                flexShrink: 0,
              }}
            >
              <Icons.Menu />
            </button>
            {currentGroup && (
              <div style={{ fontSize: '13px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                <span style={{ color: colors.textMuted }}>{currentGroup.title}</span>
                <span style={{ margin: '0 6px', color: colors.textMuted }}>/</span>
                <span style={{ fontWeight: 500 }}>{currentStory?.name}</span>
              </div>
            )}
          </div>
          
          {/* Viewport Selector */}
          <div style={{ display: 'flex', gap: '4px', alignItems: 'center', flexShrink: 0 }}>
            <div style={{ display: 'flex', backgroundColor: colors.bgTertiary, padding: '3px', borderRadius: '6px', gap: '2px' }}>
              {([
                { key: 'mobile' as Breakpoint, Icon: Icons.Mobile },
                { key: 'tablet' as Breakpoint, Icon: Icons.Tablet },
                { key: 'desktop' as Breakpoint, Icon: Icons.Desktop },
                { key: 'full' as Breakpoint, Icon: Icons.Expand },
              ]).map(({ key, Icon }) => (
                <button
                  key={key}
                  onClick={() => setBreakpoint(key)}
                  title={`${key.charAt(0).toUpperCase() + key.slice(1)} (${BREAKPOINTS[key].label})`}
                  style={{
                    padding: '5px 8px',
                    borderRadius: '4px',
                    border: 'none',
                    cursor: 'pointer',
                    backgroundColor: breakpoint === key ? colors.primary : 'transparent',
                    color: breakpoint === key ? '#fff' : colors.textMuted,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon />
                </button>
              ))}
            </div>
            <div style={{ width: '1px', height: '20px', backgroundColor: colors.border, margin: '0 4px' }} />
            <button
              onClick={toggleShowCode}
              title="Toggle code"
              style={{
                padding: '5px 8px',
                borderRadius: '4px',
                border: 'none',
                cursor: 'pointer',
                backgroundColor: showCode ? colors.primary : colors.bgTertiary,
                color: showCode ? '#fff' : colors.textMuted,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icons.Code />
            </button>
          </div>
        </div>

        {/* Content Area - Scrollable */}
        <div style={{ flex: 1, overflow: 'auto', padding: '20px' }}>
          {currentStory ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', maxWidth: '1200px' }}>
              {/* Canvas Section */}
              <section>
                <div style={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center',
                  padding: '32px 20px',
                  borderRadius: '8px',
                  border: `1px solid ${colors.border}`,
                  backgroundColor: colors.bgTertiary,
                  minHeight: '100px',
                  overflow: 'auto',
                }}>
                  <div style={{ 
                    width: BREAKPOINTS[breakpoint].width,
                    maxWidth: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    transition: 'width 0.2s ease',
                  }}>
                    <currentStory.component {...mergedArgs} />
                  </div>
                </div>
                {breakpoint !== 'full' && (
                  <div style={{ textAlign: 'center', fontSize: '11px', color: colors.textMuted, marginTop: '8px' }}>
                    Viewport: {BREAKPOINTS[breakpoint].label}
                  </div>
                )}
              </section>

              {/* Code Section */}
              {showCode && currentStory.code && (
                <section>
                  <div
                    style={{
                      borderRadius: '8px',
                      overflow: 'hidden',
                      backgroundColor: colors.bgSecondary,
                      border: `1px solid ${colors.border}`,
                    }}
                  >
                    <div
                      style={{
                        padding: '8px 12px',
                        borderBottom: `1px solid ${colors.border}`,
                        fontSize: '11px',
                        fontWeight: 600,
                        color: colors.textMuted,
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        textTransform: 'uppercase',
                        letterSpacing: '0.05em',
                      }}
                    >
                      <span>Code</span>
                      <button
                        onClick={() => navigator.clipboard.writeText(currentStory.code || '')}
                        style={{
                          background: 'none',
                          border: 'none',
                          color: colors.primary,
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '4px',
                          fontSize: '11px',
                        }}
                      >
                        <Icons.Copy /> Copy
                      </button>
                    </div>
                    <pre
                      style={{
                        padding: '14px',
                        margin: 0,
                        overflow: 'auto',
                        fontSize: '13px',
                        fontFamily: '"Fira Code", "JetBrains Mono", monospace',
                        lineHeight: 1.6,
                      }}
                    >
                      <code>{currentStory.code}</code>
                    </pre>
                  </div>
                </section>
              )}

              {/* Controls Section - Better editing */}
              {propEntries.length > 0 && (
                <section>
                  <h3 style={{ 
                    fontSize: '11px', 
                    fontWeight: 600, 
                    marginBottom: '10px', 
                    color: colors.textMuted,
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                  }}>
                    Controls
                  </h3>
                  <div style={{ 
                    display: 'grid', 
                    gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', 
                    gap: '12px',
                    padding: '14px',
                    borderRadius: '8px',
                    backgroundColor: colors.bgSecondary,
                    border: `1px solid ${colors.border}`,
                  }}>
                    {propEntries.map((prop) => (
                      <div key={prop.name} style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                        <label style={{ 
                          fontSize: '12px', 
                          fontWeight: 500, 
                          color: colors.text,
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px',
                        }}>
                          {prop.name}
                          <span style={{ 
                            fontSize: '10px', 
                            color: colors.textMuted, 
                            fontFamily: 'monospace',
                            backgroundColor: colors.bgTertiary,
                            padding: '1px 4px',
                            borderRadius: '3px',
                          }}>
                            {prop.type}
                          </span>
                        </label>
                        {prop.type === 'boolean' ? (
                          <label style={{ 
                            display: 'flex', 
                            alignItems: 'center', 
                            gap: '8px',
                            cursor: 'pointer',
                          }}>
                            <input
                              type="checkbox"
                              checked={prop.value as boolean}
                              onChange={(e) => setLiveArgs({ ...liveArgs, [prop.name]: e.target.checked })}
                              style={{ 
                                cursor: 'pointer', 
                                width: '16px', 
                                height: '16px',
                                accentColor: colors.primary,
                              }}
                            />
                            <span style={{ fontSize: '12px', color: colors.textMuted }}>
                              {prop.value ? 'true' : 'false'}
                            </span>
                          </label>
                        ) : prop.options ? (
                          <select
                            value={String(prop.value)}
                            onChange={(e) => setLiveArgs({ ...liveArgs, [prop.name]: e.target.value })}
                            style={{
                              padding: '7px 10px',
                              borderRadius: '6px',
                              border: `1px solid ${colors.border}`,
                              backgroundColor: colors.bg,
                              color: 'inherit',
                              fontSize: '13px',
                              cursor: 'pointer',
                            }}
                          >
                            {prop.options.map((opt) => (
                              <option key={opt} value={opt}>{opt}</option>
                            ))}
                          </select>
                        ) : prop.type === 'number' ? (
                          <input
                            type="number"
                            value={prop.value as number}
                            onChange={(e) => setLiveArgs({ ...liveArgs, [prop.name]: Number(e.target.value) })}
                            style={{
                              padding: '7px 10px',
                              borderRadius: '6px',
                              border: `1px solid ${colors.border}`,
                              backgroundColor: colors.bg,
                              color: 'inherit',
                              fontSize: '13px',
                            }}
                          />
                        ) : (
                          <input
                            type="text"
                            value={String(prop.value)}
                            onChange={(e) => setLiveArgs({ ...liveArgs, [prop.name]: e.target.value })}
                            style={{
                              padding: '7px 10px',
                              borderRadius: '6px',
                              border: `1px solid ${colors.border}`,
                              backgroundColor: colors.bg,
                              color: 'inherit',
                              fontSize: '13px',
                            }}
                          />
                        )}
                      </div>
                    ))}
                  </div>
                </section>
              )}

              {/* Props Table Section */}
              <section>
                <h3 style={{ 
                  fontSize: '11px', 
                  fontWeight: 600, 
                  marginBottom: '10px', 
                  color: colors.textMuted,
                  textTransform: 'uppercase',
                  letterSpacing: '0.05em',
                }}>
                  Props
                </h3>
                {propEntries.length > 0 ? (
                  <div style={{ 
                    borderRadius: '8px',
                    overflow: 'hidden',
                    border: `1px solid ${colors.border}`,
                  }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px' }}>
                      <thead>
                        <tr style={{ backgroundColor: colors.bgSecondary }}>
                          <th style={{ textAlign: 'left', padding: '10px 14px', fontWeight: 600, color: colors.textMuted, borderBottom: `1px solid ${colors.border}` }}>Name</th>
                          <th style={{ textAlign: 'left', padding: '10px 14px', fontWeight: 600, color: colors.textMuted, borderBottom: `1px solid ${colors.border}` }}>Type</th>
                          <th style={{ textAlign: 'left', padding: '10px 14px', fontWeight: 600, color: colors.textMuted, borderBottom: `1px solid ${colors.border}` }}>Default</th>
                        </tr>
                      </thead>
                      <tbody>
                        {propEntries.map((prop, i) => (
                          <tr key={prop.name} style={{ backgroundColor: i % 2 === 0 ? colors.bg : colors.bgSecondary }}>
                            <td style={{ padding: '10px 14px', fontFamily: 'monospace', color: colors.primary, fontWeight: 500 }}>{prop.name}</td>
                            <td style={{ padding: '10px 14px', fontFamily: 'monospace', color: colors.textMuted }}>{prop.type}</td>
                            <td style={{ padding: '10px 14px', fontFamily: 'monospace' }}>{JSON.stringify(prop.defaultValue)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p style={{ color: colors.textMuted, fontSize: '13px', padding: '14px', backgroundColor: colors.bgSecondary, borderRadius: '8px', margin: 0 }}>
                    No props defined. Add <code style={{ fontFamily: 'monospace', backgroundColor: colors.bgTertiary, padding: '2px 6px', borderRadius: '4px' }}>args</code> to your story.
                  </p>
                )}
              </section>

              {/* Description Section */}
              {(currentStory.description || currentGroup?.description) && (
                <section>
                  <h3 style={{ 
                    fontSize: '11px', 
                    fontWeight: 600, 
                    marginBottom: '10px', 
                    color: colors.textMuted,
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                  }}>
                    Description
                  </h3>
                  <div style={{ 
                    padding: '14px',
                    borderRadius: '8px',
                    backgroundColor: colors.bgSecondary,
                    border: `1px solid ${colors.border}`,
                    fontSize: '13px',
                    lineHeight: 1.6,
                  }}>
                    {currentStory.description && <p style={{ margin: 0 }}>{currentStory.description}</p>}
                    {currentGroup?.description && currentStory.description && <hr style={{ border: 'none', borderTop: `1px solid ${colors.border}`, margin: '12px 0' }} />}
                    {currentGroup?.description && <p style={{ margin: 0, color: colors.textMuted }}>{currentGroup.description}</p>}
                  </div>
                </section>
              )}
            </div>
          ) : (
            <div
              style={{
                height: '100%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: colors.textMuted,
                flexDirection: 'column',
                gap: '12px',
              }}
            >
              <KilnLogo size={48} primaryColor={colors.primary} />
              <span style={{ fontSize: '13px' }}>Select a component to preview</span>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

/**
 * Kiln Logo - Clean furnace with flame
 */
const KilnLogo: FC<{ size?: number; primaryColor?: string }> = ({ size = 32, primaryColor = '#0891b2' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
    {/* Kiln arch */}
    <path
      d="M5 18V10C5 6 8.5 4 12 4C15.5 4 19 6 19 10V18"
      fill="none"
      stroke={primaryColor}
      strokeWidth="2"
      strokeLinecap="round"
    />
    {/* Base */}
    <rect x="4" y="18" width="16" height="2" rx="1" fill={primaryColor} opacity="0.4" />
    {/* Flame */}
    <path
      d="M12 16C11 16 10.3 15 10.5 14C10.7 13 11.5 12.5 12 11.5C12.5 12.5 13.3 13 13.5 14C13.7 15 13 16 12 16Z"
      fill={primaryColor}
    >
      <animate
        attributeName="d"
        values="M12 16C11 16 10.3 15 10.5 14C10.7 13 11.5 12.5 12 11.5C12.5 12.5 13.3 13 13.5 14C13.7 15 13 16 12 16Z;
                M12 16C11.2 16 10.5 15 10.6 14C10.8 12.8 11.4 12 12 11C12.6 12 13.2 12.8 13.4 14C13.5 15 12.8 16 12 16Z;
                M12 16C11 16 10.3 15 10.5 14C10.7 13 11.5 12.5 12 11.5C12.5 12.5 13.3 13 13.5 14C13.7 15 13 16 12 16Z"
        dur="0.7s"
        repeatCount="indefinite"
      />
    </path>
  </svg>
);
