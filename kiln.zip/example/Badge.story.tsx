/**
 * Badge Story for Kiln
 * Shows status indicators and labels
 */

import { defineStory, defineStories } from '../src';

// Example Badge component
const Badge = ({
  variant = 'default',
  size = 'md',
  dot = false,
  children,
}: {
  variant?: 'default' | 'success' | 'warning' | 'error' | 'info';
  size?: 'sm' | 'md' | 'lg';
  dot?: boolean;
  children: React.ReactNode;
}) => {
  const sizeStyles = {
    sm: { padding: '2px 8px', fontSize: '10px' },
    md: { padding: '4px 12px', fontSize: '12px' },
    lg: { padding: '6px 16px', fontSize: '14px' },
  };

  const variantColors = {
    default: { bg: '#27272a', text: '#a1a1aa' },
    success: { bg: '#14532d', text: '#4ade80' },
    warning: { bg: '#713f12', text: '#fbbf24' },
    error: { bg: '#7f1d1d', text: '#f87171' },
    info: { bg: '#1e3a5f', text: '#60a5fa' },
  };

  const colors = variantColors[variant];

  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: '6px',
        ...sizeStyles[size],
        backgroundColor: colors.bg,
        color: colors.text,
        borderRadius: '9999px',
        fontWeight: 500,
      }}
    >
      {dot && (
        <span
          style={{
            width: '6px',
            height: '6px',
            borderRadius: '50%',
            backgroundColor: colors.text,
          }}
        />
      )}
      {children}
    </span>
  );
};

export default defineStories({
  title: 'Badge',
  component: Badge,
  description: 'Small status indicators and labels for tagging content.',
  stories: [
    defineStory({
      name: 'Default',
      render: Badge,
      args: { children: 'Default' },
      code: `<Badge>Default</Badge>`,
      description: 'Neutral badge for general labels.',
    }),
    defineStory({
      name: 'Success',
      render: Badge,
      args: { variant: 'success', children: 'Active' },
      code: `<Badge variant="success">Active</Badge>`,
      description: 'Green badge for positive status.',
    }),
    defineStory({
      name: 'Warning',
      render: Badge,
      args: { variant: 'warning', children: 'Pending' },
      code: `<Badge variant="warning">Pending</Badge>`,
      description: 'Yellow badge for attention-needed items.',
    }),
    defineStory({
      name: 'Error',
      render: Badge,
      args: { variant: 'error', children: 'Failed' },
      code: `<Badge variant="error">Failed</Badge>`,
      description: 'Red badge for errors or critical status.',
    }),
    defineStory({
      name: 'Info',
      render: Badge,
      args: { variant: 'info', children: 'New' },
      code: `<Badge variant="info">New</Badge>`,
      description: 'Blue badge for informational labels.',
    }),
    defineStory({
      name: 'With Dot',
      render: Badge,
      args: { variant: 'success', dot: true, children: 'Online' },
      code: `<Badge variant="success" dot>Online</Badge>`,
      description: 'Badge with status dot indicator.',
    }),
  ],
});

